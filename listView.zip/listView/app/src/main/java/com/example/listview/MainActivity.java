package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    ListView list;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        list = (ListView) findViewById(R.id.myList);

        //String[] names = {"Jan", "Artur", "Adam", "Jerzy", "Konrad"};

        //ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.simplerow, R.id.textList, names);

        //list.setAdapter(adapter);

        List<person> personList = new ArrayList<>();

        personList.add(new person("Olaf", "Nowak", 43));
        personList.add(new person("Jan", "Kargul", 59));
        personList.add(new person("Zmien", "naPubliczna", 1));


        myAdapter myadapter = new myAdapter(this, personList);
        list.setAdapter(myadapter);

    }
}