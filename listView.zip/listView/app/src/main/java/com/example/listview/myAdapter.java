package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class myAdapter extends BaseAdapter{

    private Context context;
    private List<person> personList;
    private LayoutInflater layoutInflater;

    public myAdapter(Context context, List<person> personList) {
        this.context = context;
        this.personList = personList;

        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return personList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //generujemy widok przy pomocy layout inflatera
        View view = layoutInflater.inflate(R.layout.customrow, parent, false);
        TextView name = (TextView) view.findViewById(R.id.text_name);
        TextView surname = (TextView) view.findViewById(R.id.text_surname);
        TextView age = (TextView) view.findViewById(R.id.text_age);
        //przypisanie danych do odpowiednich pól
        name.setText(String.valueOf(personList.get(position).getName()));
        surname.setText(String.valueOf(personList.get(position).getSurname()));
        age.setText(String.valueOf(personList.get(position).getAge()));

        return view;
    }
}
