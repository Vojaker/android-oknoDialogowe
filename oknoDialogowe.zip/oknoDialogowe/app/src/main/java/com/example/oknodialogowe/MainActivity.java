package com.example.oknodialogowe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createDialog();
    }
    public void createDialog(){
        //klasa Alert i wzorzec builder
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Okno dialogowe")
                .setTitle("Witaj czy chcesz ocenić naszą aplikację?")
                .setIcon(R.mipmap.ic_launcher)
                .setCancelable(false)
                .setPositiveButton("Tak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "Dzięki, za chwilę zostaniesz przeniesiony do sklepu play", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("nie", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "Przykro mi może następnym razem ez", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }
}