package com.example.oknodialogowe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //createDialog();
        createCustomDialog();
    }
    public void createDialog() {
        //klasa Alert i wzorzec builder
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Okno dialogowe")
                .setTitle("Witaj czy chcesz ocenić naszą aplikację?")
                .setIcon(R.mipmap.ic_launcher)
                .setCancelable(false)
                .setPositiveButton("Tak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "Dzięki, za chwilę zostaniesz przeniesiony do sklepu play", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("nie", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this, "Przykro mi może następnym razem ez", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }
        //tworzymy nową metodę dla customowego okna dialogowego
        public void createCustomDialog(){
            Dialog dialog1 = new Dialog(this);
            dialog1.setContentView(R.layout.dialog);
            dialog1.setTitle("Test customowego dialogu ");

            Button exit = (Button)
                    dialog1.findViewById(R.id.button2);
                    exit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog1.dismiss();
                        }
                    });
                    dialog1.show();
        }
    }